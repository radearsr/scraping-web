require("dotenv").config();
const mysqlService = require("./services/mysql/MysqlService");
const scrapServices = require("./services/scraping/ScrapServices");
const utils = require("./utils/index");


